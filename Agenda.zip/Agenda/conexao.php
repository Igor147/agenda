<?php

    $host = "localhost";
    $database = "agenda";
    $username = "root";
    $password = "";

    $mysqli = new mysqli($host, $username, $password, $database);

    if($mysqli->connect_error)
        echo "Falha na conexao: (".$mysqli->connect_error.") ".$mysqli->connect_error;
?>