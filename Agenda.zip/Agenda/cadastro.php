<?php 
include("conexao.php");

    if($_POST['nome']){
        
        $nome   = $_POST['nome'];
        $telefone    = $_POST['telefone'];
        $email  = $_POST['email'];

        $sql = new mysqli($host, $username, $password, $database) or die("falha na conexao");
        $sql->set_charset('utf8');

        $s = $sql->prepare("INSERT INTO contato(nome,telefone,email) VALUES (?,?,?)");
        $s->bind_param('sss',$nome,$telefone,$email);
        if(!$s->execute()){
            $erro = "erro ao inserir dados no banco";
        }
        $s->close();        
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
</head>
<body>
    <h1>CADASTRO USUARIO</h1>
    <form action="edita.php" method="POST">
        <label>Nome</label> <input type="text" id="nome" name="nome"><br/><br/>
        <label>Telefone</label> <input type="text" id="telefone" name="telefone"><br/><br/>
        <label>E-mail</label> <input type="text" id="email" name="email"><br/><br/>
        <button type="submit">Enviar</button>

    </form>
</body>
</html>