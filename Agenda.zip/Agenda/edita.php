<?php 
include("conexao.php");

    $id = $_GET['id'];

    $consulta = "SELECT * FROM contato WHERE id= $id";
    $con = $mysqli->query($consulta) or die ($mysqli->error);
    $dado = $con->fetch_array();

    $sql = new mysqli($host, $username, $password, $database) or die("falha na conexao");
    $sql->set_charset('utf8');

    $s = $sql->prepare("UPDATE contato SET nome=?, email=?, telefone=? WHERE id= $id");
    $s->bind_param('sss',$nome,$email,$telefone);
    if(!$s->execute()){
        $erro = "erro ao inserir dados no banco";
    }
    $s->close();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
</head>
<body>
    <h1>Editar USUARIO</h1>
    <form action="edita.php" method="POST">
        <label>Nome</label> <input type="text" id="nome" name="nome" text="aew"><?= $dado["nome"]; ?><br/><br/>
        <label>Telefone</label> <input type="text" id="telefone" name="telefone"><?= $dado["email"]; ?><br/><br/>
        <label>E-mail</label> <input type="text" id="email" name="email"><?= $dado["telefone"]; ?><br/><br/>
        <button type="submit">Editar</button>

    </form>
</body>
</html>